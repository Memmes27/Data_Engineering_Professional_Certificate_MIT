<<<<<<< HEAD
## Flask and Jinja Web Server

Basic Web Server
=======
## flaskBookServer 1

Basic Flask Web Server with 2 Routes / (default) and /books (GET)
1 file index.html in templates
/ maps to index.html

There is no css styling and no concept of a user
>>>>>>> 4ca1d7c27843bdf1372cf469c632a6b3f4846c6c
